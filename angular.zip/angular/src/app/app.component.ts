import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';  // Ensure Router is imported here
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './layout/dashboard/dashboard.component';
import { RouterModule } from '@angular/router';  // Import RouterModule for routing functionality
import { MyprofileComponent } from './layout/myprofile/myprofile.component';
import { LoginComponent } from './layout/login/login.component';
import { GradesComponent } from './layout/grades/grades.component';
import { ScheduleComponent } from './layout/schedule/schedule.component';
import { AttendanceComponent } from './layout/attendance/attendance.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule,RouterModule],  
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
// app.component.ts
export class AppComponent{
  title = 'angular';
  isMenuOpen = false;



  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  closeMenu() {
    this.isMenuOpen = false;
  }
}